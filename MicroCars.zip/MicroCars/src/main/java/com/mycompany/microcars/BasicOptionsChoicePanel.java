/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.microcars;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class BasicOptionsChoicePanel extends JPanel implements ActionListener {

    private String[] cars = {"cyan", "red", "green", "yellow"};
    private int currentCarIndex = 0;
    
    private JFrame parentFrame;
    private CircuitImage basicTrackImage, eightTrackImage; 
    private String choosenCar;
    private String choosenTrack;
    private AlertMessage m;
    
    private JLabel carLabel;  
    
    public BasicOptionsChoicePanel(AlertMessage m, JFrame parentFrame) {
        this.m = m;
        this.parentFrame = parentFrame;

        setLayout(new GridLayout(3, 4));
        
        try {
            JLabel ip = new JLabel("Ip number = " + InetAddress.getLocalHost().getHostAddress());
            ip.setHorizontalAlignment(SwingConstants.CENTER);
            add(ip);
            
            JLabel empty2 = new JLabel("Client / Server (To Be Done)");
            empty2.setHorizontalAlignment(SwingConstants.CENTER);
            add(empty2);
            
            JLabel empty3 = new JLabel("Connect / Open Connection (To Be Done)");
            empty3.setHorizontalAlignment(SwingConstants.CENTER);
            add(empty3);
            
            JButton bPlay = new JButton("Play");
            bPlay.addActionListener(this);
            add(bPlay);
            
            JButton leftArrow = new JButton("<-");
            leftArrow.addActionListener(this);
            add(leftArrow);
            
            carLabel = new JLabel(new MicroCarSprite(cars[currentCarIndex]).convertToIcon());
            carLabel.setHorizontalAlignment(SwingConstants.CENTER);
            add(carLabel);
            
            JButton rightArrow = new JButton("->");
            rightArrow.addActionListener(this);
            add(rightArrow);

            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            basicTrackImage = new CircuitImage("basic", (int) (0.8 * screenSize.getWidth()), (int) (0.8 * screenSize.getHeight()));
            JButton bTrack1 = new JButton("Basic Track", basicTrackImage.convertToIcon());
            bTrack1.setVerticalTextPosition(AbstractButton.BOTTOM);
            bTrack1.setHorizontalTextPosition(AbstractButton.CENTER);
            bTrack1.addActionListener(this);
            add(bTrack1);
           
            eightTrackImage = new CircuitImage("eight", (int) (0.8 * screenSize.getWidth()), (int) (0.8 * screenSize.getHeight()));
            JButton bTrack2 = new JButton("Eight Track", eightTrackImage.convertToIcon());
            bTrack2.setVerticalTextPosition(AbstractButton.BOTTOM);
            bTrack2.setHorizontalTextPosition(AbstractButton.CENTER);
            bTrack2.addActionListener(this);
            add(bTrack2);
            
            JLabel empty11 = new JLabel("Custom Track (To Be Done)");
            empty11.setHorizontalAlignment(SwingConstants.CENTER);
            add(empty11);
            
            JLabel empty12 = new JLabel("Custom Track (To Be Done)");
            empty12.setHorizontalAlignment(SwingConstants.CENTER);
            add(empty12);
            
            choosenCar = cars[currentCarIndex];
            choosenTrack = "basic";
            
        } catch (UnknownHostException ex) {
            Logger.getLogger(BasicOptionsChoiceFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonPressed = e.getActionCommand();
        
        switch (buttonPressed) {
            case "<-":
                currentCarIndex = (currentCarIndex - 1 + cars.length) % cars.length;
                break;
                
            case "->":
                currentCarIndex = (currentCarIndex + 1) % cars.length;
                break;
                
            case "Play":
                m.setMessage(choosenTrack + ";" + choosenCar);
                parentFrame.dispose();
                break;

            case "Basic Track":
                choosenTrack = "basic";
                break;

            case "Eight Track":
                choosenTrack = "eight";
                break;

            default:
                break;
        }

        choosenCar = cars[currentCarIndex];
        carLabel.setIcon(new MicroCarSprite(choosenCar).convertToIcon());
    }
}
